EntityEvents.spawned('monsterexpansion:skrythe', event => {
  const entity = event.entity

  // 最大HPを100に固定
  entity.setMaxHealth(100)
  entity.setHealth(100)

  // 攻撃力を元の20%にする（安全なやり方）
  entity.modifyAttribute(
    'minecraft:generic.attack_damage',
    'skrythe_nerf',
    -0.8,
    'multiply_total'
  )
})
