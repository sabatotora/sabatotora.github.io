LootJS.modifiers(event => {
  event.addEntityLootModifier('irons_spellbooks:archevoker')
    .removeLoot('irons_spellbooks:scroll')

    .removeLoot('irons_spellbooks:common_ink')
    .removeLoot('irons_spellbooks:uncommon_ink')
    .removeLoot('irons_spellbooks:rare_ink')
    .removeLoot('irons_spellbooks:epic_ink')
    .removeLoot('irons_spellbooks:legendary_ink')

    .addLoot(
      Item.of('irons_spellbooks:common_ink', 3)
    )

    .addLoot(
      Item.of('irons_spellbooks:uncommon_ink', 3)
    )

    .addLoot(
      Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:fang_ward",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}')
    )

    // ここからランダム2つ
    .apply(ctx => {
      const pool = [
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:fang_strike",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:firecracker",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:summon_horse",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:arrow_volley",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:chain_creeper",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}')
      ]

      // シャッフル
      pool.sort(() => Math.random() - 0.5)

      // 先頭2つをドロップ
      ctx.addLoot(pool[0])
      ctx.addLoot(pool[1])
    })
})
