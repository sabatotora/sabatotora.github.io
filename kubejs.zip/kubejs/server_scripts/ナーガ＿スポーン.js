ItemEvents.rightClicked(event => {
  const player = event.player
  const level = player.level
  if (level.isClientSide()) return

  if (event.item.id !== 'wildernature:venison') return

  // 🔻 まず必ず1個消費
  event.item.shrink(1)

  // 🎲 1/10の確率で成功
  if (Math.random() >= 0.1) {
    player.tell('§7……何も起こらなかった')
    return
  }

  player.tell('§a鹿肉が捧げられた…')

  const x = Math.floor(player.x + 2)
  const y = Math.floor(player.y + 10)
  const z = Math.floor(player.z + 2)

  player.server.runCommandSilent(
    `summon mowziesmobs:naga ${x} ${y} ${z}`
  )

  player.server.runCommandSilent(
    `advancement grant ${player.username} only kenma:naga_summon`
  )
})
