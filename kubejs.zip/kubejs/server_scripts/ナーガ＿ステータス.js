EntityEvents.spawned(event => {
  const entity = event.entity
  if (!entity || entity.level.isClientSide()) return

  // ナーガだけ対象
  if (entity.type !== 'mowziesmobs:naga') return

  const attr = entity.getAttribute('minecraft:generic.attack_damage')
  if (!attr) return

  // 攻撃力を2倍
  attr.setBaseValue(attr.getBaseValue() * 2)
})
