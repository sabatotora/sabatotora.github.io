ServerEvents.recipes(event => {

  // 念のため既存レシピを削除
  event.remove({ output: 'irons_spellbooks:scroll_forge' })

  // 新しいクラフトレシピ
  event.shaped(
    'irons_spellbooks:scroll_forge',
    [
      'ABC',
      'DEI',
      'FGH'
    ],
    {
      A: Item.of('irons_spellbooks:fire_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:fire_power"}'),
      B: Item.of('irons_spellbooks:ice_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:ice_power"}'),
      C: Item.of('irons_spellbooks:lightning_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:lightning_power"}'),

      D: Item.of('irons_spellbooks:nature_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:nature_power"}'),
      E: 'minecraft:anvil',
      F: Item.of('irons_spellbooks:evocation_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:evocation_power"}'),

      G: Item.of('irons_spellbooks:blood_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:blood_power"}'),
      H: Item.of('irons_spellbooks:holy_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:holy_power"}'),
      I: Item.of('irons_spellbooks:ender_upgrade_orb', '{"irons_spellbooks:upgrade_orb_type":"irons_spellbooks:ender_power"}')
    }
  )
})
