ServerEvents.recipes(event => {
  event.shaped(
    'minecraft:netherite_ingot',
    [
      '   ',
      ' D ',
      '   '
    ],
    {
      D: 'monsterexpansion:vocal_resonance_fold'
    }
  )
})
