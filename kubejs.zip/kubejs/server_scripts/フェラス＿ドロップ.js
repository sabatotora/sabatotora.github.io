LootJS.modifiers(event => {
  event.addEntityLootModifier('mowziesmobs:ferrous_wroughtnaut')
    .addLoot(
      Item.of('irons_spellbooks:lightning_rune')
    )

    .addLoot(
      Item.of('irons_spellbooks:common_ink', 3)
    )

    .addLoot(
      Item.of('irons_spellbooks:uncommon_ink', 3)
    )

    .addLoot(
      Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:lightning_lance",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}')
    )

    // ここからランダム2つ
    .apply(ctx => {
      const pool = [
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:electrocute",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:chain_lightning",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:shockwave",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:ball_lightning",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll', '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:volt_strike",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}')
      ]

      // シャッフル
      pool.sort(() => Math.random() - 0.5)

      // 先頭2つをドロップ
      ctx.addLoot(pool[0])
      ctx.addLoot(pool[1])
    })
})
