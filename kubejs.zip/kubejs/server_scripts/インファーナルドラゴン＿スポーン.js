EntityEvents.spawned('block_factorys_bosses:infernal_dragon', event => {
  const level = event.level
  if (level.isClientSide()) return

  const dragon = event.entity

  // 近くのプレイヤーを取得
  const players = level.getPlayers(p => p.distanceTo(dragon) < 48)
  if (players.isEmpty()) return

  const player = players[0]

  // L2 Hostility の現在値
  const hostility = player.getScore('l2hostility.level')

  // すでに50以上なら何もしない
  if (hostility >= 50) return

  const x = dragon.x
  const y = dragon.y
  const z = dragon.z
  const yaw = dragon.yaw
  const pitch = dragon.pitch

  // 元ドラゴン削除
  dragon.discard()

  // Hostilityを一時的に50へ
  level.server.runCommandSilent(
    `scoreboard players set ${player.username} l2hostility.level 50`
  )

  // 再スポーン（この瞬間に50として評価される）
  level.server.runCommandSilent(
    `summon block_factorys_bosses:infernal_dragon ${x} ${y} ${z} {Rotation:[${yaw}f,${pitch}f]}`
  )

  // ★2tick後に元へ戻す（重要）
  level.server.scheduleInTicks(2, () => {
    level.server.runCommandSilent(
      `scoreboard players set ${player.username} l2hostility.level ${hostility}`
    )
  })
})
