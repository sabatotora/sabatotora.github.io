LootJS.modifiers(event => {
  event.addEntityLootModifier('irons_spellbooks:priest')
    .removeLoot('irons_spellbooks:scroll')

    .removeLoot('irons_spellbooks:common_ink')
    .removeLoot('irons_spellbooks:uncommon_ink')
    .removeLoot('irons_spellbooks:rare_ink')
    .removeLoot('irons_spellbooks:epic_ink')
    .removeLoot('irons_spellbooks:legendary_ink')

    // ✅ common_ink を3個固定ドロップ
    .addLoot(
      Item.of('irons_spellbooks:common_ink', 3)
    )

    // ✅ uncommon_ink を3個固定ドロップ
    .addLoot(
      Item.of('irons_spellbooks:uncommon_ink', 3)
    )

    // ヒールは確定ドロップ
    .addLoot(
      Item.of(
        'irons_spellbooks:scroll',
        '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:heal",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
      )
    )

    // ここからランダム2つ
    .apply(ctx => {
      const pool = [
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:healing_circle",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:wisp",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:sunbeam",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:guiding_bolt",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:divine_smite",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        )
      ]

      // シャッフル
      pool.sort(() => Math.random() - 0.5)

      // 先頭2つをドロップ
      ctx.addLoot(pool[0])
      ctx.addLoot(pool[1])
    })
})

