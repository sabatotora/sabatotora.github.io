EntityEvents.hurt('mowziesmobs:ferrous_wroughtnaut', event => {
  const player = event.source.player
  if (!player) return

  const level = event.level
  if (level.isClientSide()) return

  const x = Math.floor(player.x)
  const y = Math.floor(player.y)
  const z = Math.floor(player.z)

  for (let i = 0; i < 3; i++) {
    level.server.scheduleInTicks(i * 4, () => {

      // ⚡ 雷音
      level.playSound(null, x, y, z,
        'minecraft:entity.lightning_bolt.thunder',
        'weather', 1.0, 1.0
      )

      // ✨ フラッシュ
      level.server.runCommandSilent(
        `particle minecraft:flash ${x} ${y + 1} ${z} 0 0 0 0 1 force`
      )

      // ✨ 電気スパーク
      level.server.runCommandSilent(
        `particle minecraft:electric_spark ${x} ${y + 1} ${z} 0.6 1.2 0.6 0.2 30 force`
      )

      // 💀 雷反撃ダメージ（確実に通る）
      level.server.runCommandSilent(
        `execute as ${player.uuid} run damage @s 3 magic`
      )
    })
  }
})
