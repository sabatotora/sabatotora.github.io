ServerEvents.recipes(event => {

  // 念のため既存レシピを削除
  event.remove({ output: 'irons_spellbooks:arcane_anvil' })

  // 新しいクラフトレシピ
  event.shaped(
    'irons_spellbooks:arcane_anvil',
    [
      'ABC',
      'DEI',
      'FGH'
    ],
    {
      A: 'irons_spellbooks:fire_rune',
      B: 'irons_spellbooks:ice_rune',
      C: 'irons_spellbooks:lightning_rune',

      D: 'irons_spellbooks:nature_rune',
      E: 'minecraft:anvil',
      F: 'irons_spellbooks:evocation_rune',

      G: 'irons_spellbooks:blood_rune',
      H: 'irons_spellbooks:holy_rune',
      I: 'irons_spellbooks:ender_rune'
    }
  )
})
