LootJS.modifiers(event => {

  function getTrueMaxHealth(entity) {
    const attrs = entity.nbt.Attributes
    if (!attrs) return 20

    for (const a of attrs) {
      if (a.Name === 'minecraft:generic.max_health') {
        let hp = a.Base ?? 20

        if (a.Modifiers) {
          for (const m of a.Modifiers) {
            // Operation 0 = 加算（Mutant系はこれ）
            if (m.Operation === 0) {
              hp += m.Amount
            }
            // Operation 1 / 2 は倍率（念のため）
            if (m.Operation === 1) {
              hp += hp * m.Amount
            }
            if (m.Operation === 2) {
              hp *= (1 + m.Amount)
            }
          }
        }
        return hp
      }
    }
    return 20
  }

  event
    .addEntityLootModifier('mutantmonsters:mutant_zombie')
    .apply(ctx => {
      const hp = getTrueMaxHealth(ctx.entity)

      // デバッグ用（最初だけ推奨）
      // console.log('True MaxHP =', hp)

      if (hp >= 500) {
        ctx.addLoot(Item.of('l2artifacts:artifact_experience_5', 5))
      } else if (hp >= 400) {
        ctx.addLoot(Item.of('l2artifacts:artifact_experience_4', 5))
      } else if (hp >= 300) {
        ctx.addLoot(Item.of('l2artifacts:artifact_experience_3', 5))
      } else if (hp >= 200) {
        ctx.addLoot(Item.of('l2artifacts:artifact_experience_2', 5))
      } else {
        ctx.addLoot(Item.of('l2artifacts:artifact_experience_1', 5))
      }
    })
})
