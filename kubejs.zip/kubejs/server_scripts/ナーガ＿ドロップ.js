LootJS.modifiers(event => {
  event.addEntityLootModifier('mowziesmobs:naga')
    .addLoot(
      Item.of('irons_spellbooks:nature_rune')
    )

    .addLoot(
      Item.of('irons_spellbooks:common_ink', 3)
    )

    .addLoot(
      Item.of('irons_spellbooks:uncommon_ink', 3)
    )

    .addLoot(
      Item.of('irons_spellbooks:scroll',
        '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:poison_arrow",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
      )
    )

    // ここからランダム2つ
    .apply(ctx => {
      const pool = [
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:firefly_swarm",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:root",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:poison_splash",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:poison_breath",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        ),
        Item.of('irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:acid_orb",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        )
      ]

      // シャッフル
      pool.sort(() => Math.random() - 0.5)

      // 先頭2つをドロップ
      ctx.addLoot(pool[0])
      ctx.addLoot(pool[1])
    })
})
