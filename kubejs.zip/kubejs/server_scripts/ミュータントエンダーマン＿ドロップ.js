LootJS.modifiers(event => {
  event.addEntityLootModifier('mutantmonsters:mutant_enderman')
    .apply(ctx => {
      const entity = ctx.getEntity()

      // 🔒 すでに処理済みなら何もしない
      if (entity.persistentData.kjs_loot_done) return

      // ✅ 最初の1回だけフラグを立てる
      entity.persistentData.kjs_loot_done = true

      // ===== 固定ドロップ =====
      ctx.addLoot(Item.of('irons_spellbooks:ender_rune'))
      ctx.addLoot(Item.of('irons_spellbooks:common_ink', 3))
      ctx.addLoot(Item.of('irons_spellbooks:uncommon_ink', 3))

      ctx.addLoot(
        Item.of(
          'irons_spellbooks:scroll',
          '{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:teleport",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'
        )
      )

      // ===== ランダム2スクロール =====
      const pool = [
        Item.of('irons_spellbooks:scroll','{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:shadow_slash",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll','{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:dragon_breath",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll','{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:starfall",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll','{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:magic_missile",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}'),
        Item.of('irons_spellbooks:scroll','{"irons_spellbooks:spell_container":{data:[{id:"irons_spellbooks:recall",index:0,level:1,locked:1b}],maxSpells:1,mustEquip:0b,spellWheel:0b}}')
      ]

      pool.sort(() => Math.random() - 0.5)
      ctx.addLoot(pool[0])
      ctx.addLoot(pool[1])
    })
})
