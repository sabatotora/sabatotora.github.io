ServerEvents.recipes(event => {
  event.shapeless(
    Item.of('minecraft:written_book').withNBT({
      title: "剣魔の世界ガイドブック",
      author: "？",
      pages: [
        '{"text":"剣魔の世界のガイドブック、木の剣と本1個ずつを並べてクラフト可能、URLを押して変化がなくても検索エンジンのほうで開かれてるよ\\n\\n","extra":[{"text":"▶ Webで開く","color":"blue","underlined":true,"clickEvent":{"action":"open_url","value":"https://sabatotora.github.io/"}}]}'
      ]
    }),
    [
      'minecraft:book',
      'minecraft:wooden_sword'
    ]
  ).id('kenma:web_guide_book')
})
