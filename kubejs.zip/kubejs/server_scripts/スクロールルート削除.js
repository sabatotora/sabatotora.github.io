LootJS.modifiers(event => {
  event
    .addLootTypeModifier(LootType.CHEST)
    // 魔法スクロール全削除
    .removeLoot(/irons_spellbooks:.*scroll.*/)
    // 空白ルーンも削除
    .removeLoot('irons_spellbooks:blank_rune')
    .removeLoot('irons_spellbooks:uncommon_ink')
    .removeLoot('irons_spellbooks:rare_ink')
    .removeLoot('irons_spellbooks:epic_ink')
    .removeLoot('irons_spellbooks:legendary_ink')
    .removeLoot('traveloptics:lightning_echo')
})
