// kubejs/server_scripts/protection5_recipe.js
ServerEvents.recipes(event => {
  event.shaped(
    Item.of('minecraft:enchanted_book')
      .enchant('minecraft:protection', 5),
    [
      'DDD',
      'DBD',
      'DDD'
    ],
    {
      D: 'monsterexpansion:skrythe_armorplate',
      B: Item.of('minecraft:enchanted_book')
        .enchant('minecraft:protection', 4)
    }
  )
})

ServerEvents.recipes(event => {
  event.shaped(
    Item.of('minecraft:enchanted_book')
      .enchant('minecraft:protection', 6),
    [
      'CDC',
      'DBD',
      'CDC'
    ],
    {
      C: 'monsterexpansion:monster_hardbone',
      D: 'monsterexpansion:skrythe_wing_membrane',
      B: Item.of('minecraft:enchanted_book')
        .enchant('minecraft:protection', 5)
    }
  )
})
