LootJS.modifiers(event => {
  event
    .addEntityLootModifier('monsterexpansion:skrythe')
    .addLoot(Item.of('minecraft:netherite_ingot', 4))
})
