ServerEvents.recipes(event => {
    event.shaped(
        '10x minecraft:stone',
        [
            'A B',
            ' C ',
            'B A'
        ],
        {
            A: 'minecraft:andesite',
            B: 'minecraft:diorite',
            C: 'minecraft:granite'
        }
    )
})
ServerEvents.recipes(event => {
    event.shaped(
        '5x l2complements:force_field',
        [
            'A A',
            ' B ',
            'A A'
        ],
        {
            A: 'minecraft:feather',
            B: 'mowziesmobs:naga_fang'
        }
    )
})        
ServerEvents.recipes(event => {
    event.shaped(
        'minecraft:crying_obsidian',
        [
            ' A ',
            ' B ',
            ' A '
        ],
        {
            A: 'minecraft:amethyst_shard',
            B: 'minecraft:obsidian'
        }
    )
})
